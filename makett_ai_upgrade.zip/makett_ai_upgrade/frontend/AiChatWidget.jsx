import React, { useRef, useState } from "react";

const API_BASE = (import.meta?.env?.VITE_API_URL || "http://localhost:3001").replace(/\/$/, "");

export default function AiChatWidget() {
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState([]); // {from:"user"|"bot", text, sources?}
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);
  const abortRef = useRef(null);

  async function send(e) {
    e?.preventDefault();
    const text = msg.trim();
    if (!text || loading) return;

    setErr(null);
    setMessages((prev) => [...prev, { from: "user", text }]);
    setMsg("");

    try {
      setLoading(true);
      if (abortRef.current) abortRef.current.abort();
      abortRef.current = new AbortController();

      const res = await fetch(`${API_BASE}/api/ai/ask`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: text }),
        signal: abortRef.current.signal,
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || "Hiba az AI hívásakor.");

      const reply = (data?.reply && String(data.reply).trim()) || "Nincs válasz.";
      setMessages((prev) => [...prev, { from: "bot", text: reply, sources: data?.sources }]);
    } catch (ex) {
      if (ex?.name === "AbortError") return;
      console.error(ex);
      setErr(ex.message || "Ismeretlen hiba.");
      setMessages((p) => [...p, { from: "bot", text: "Most nem tudok válaszolni: " + (ex.message || "") }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <button className="ai-fab" type="button" onClick={() => setOpen((o) => !o)}>
        🤖
      </button>

      {open && (
        <div className="ai-chat-window">
          <div className="ai-chat-header">
            <strong>MakettMester – AI</strong>
            <button className="ai-chat-close" type="button" onClick={() => setOpen(false)}>
              ×
            </button>
          </div>

          <div className="ai-chat-body">
            {messages.length === 0 && <p className="ai-chat-hint">Kérdezz építésről, festésről, matricáról, hibákról.</p>}
            {err && <p className="error">{err}</p>}

            {messages.map((m, i) => (
              <div key={i} className={m.from === "user" ? "ai-msg ai-msg-user" : "ai-msg ai-msg-bot"}>
                <span style={{ whiteSpace: "pre-wrap" }}>{m.text}</span>

                {m.from === "bot" && m.sources?.web?.length > 0 && (
                  <div className="ai-sources">
                    <div className="ai-sources-title">Források:</div>
                    <ul>
                      {m.sources.web.slice(0, 5).map((s, idx) => (
                        <li key={idx}>
                          <a href={s.href} target="_blank" rel="noreferrer">
                            {s.title}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}

            {loading && <p className="ai-chat-hint">Gondolkodom…</p>}
          </div>

          <form className="ai-chat-footer" onSubmit={send}>
            <input placeholder="Írd ide…" value={msg} onChange={(e) => setMsg(e.target.value)} disabled={loading} />
            <button disabled={loading || !msg.trim()}>Küldés</button>
          </form>
        </div>
      )}
    </>
  );
}
