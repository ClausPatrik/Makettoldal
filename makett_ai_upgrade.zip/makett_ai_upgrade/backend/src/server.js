import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import aiRouter from "./routes/ai.js";

const app = express();

app.use(helmet());
app.use(express.json({ limit: "1mb" }));

const corsOrigin = process.env.CORS_ORIGIN || "http://localhost:5173";
app.use(cors({ origin: corsOrigin, credentials: true }));

app.use(rateLimit({
  windowMs: 60_000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false
}));

app.get("/health", (req, res) => res.json({ ok: true }));

app.use("/api/ai", aiRouter);

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`Makett AI backend fut: http://localhost:${port}`);
});
