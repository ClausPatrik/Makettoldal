import express from "express";
import { q } from "../lib/db.js";
import { duckDuckGoSearch } from "../lib/websearch.js";
import { buildReply } from "../lib/answer.js";

const router = express.Router();

function clampInt(v, def, min, max) {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, Math.trunc(n)));
}

async function searchLocalKnowledge(question, limit = 5) {
  // Ha nincs tábla, ne dobjon szét mindent.
  try {
    // FULLTEXT ha van, különben LIKE.
    // (Ha nincs FULLTEXT index, a MATCH dobhat hibát.)
    try {
      const rows = await q(
        `SELECT id, title, tag, content, answer
         FROM ai_knowledge
         WHERE MATCH(title, tag, content, answer) AGAINST (? IN NATURAL LANGUAGE MODE)
         LIMIT ?`,
        [question, limit]
      );
      if (rows?.length) return rows;
    } catch {
      // fallback LIKE
    }
    const like = `%${question.slice(0, 120)}%`;
    const rows2 = await q(
      `SELECT id, title, tag, content, answer
       FROM ai_knowledge
       WHERE title LIKE ? OR tag LIKE ? OR content LIKE ? OR answer LIKE ?
       ORDER BY id DESC
       LIMIT ?`,
      [like, like, like, like, limit]
    );
    return rows2 || [];
  } catch {
    return [];
  }
}

router.post("/ask", async (req, res) => {
  const question = (req.body?.question || "").toString().trim();
  const userId = req.body?.userId ?? null;

  if (!question) return res.status(400).json({ error: "Hiányzik a kérdés." });

  const webEnabled = String(process.env.AI_ENABLE_WEB || "true").toLowerCase() === "true";
  const maxWeb = clampInt(process.env.AI_WEB_MAX_RESULTS, 5, 0, 10);

  const localSnippets = await searchLocalKnowledge(question, 5);

  let webResults = [];
  if (webEnabled && maxWeb > 0) {
    try {
      webResults = await duckDuckGoSearch(question + " scale model", maxWeb);
    } catch (e) {
      webResults = [];
    }
  }

  const reply = buildReply({ question, localSnippets, webResults });

  const sources = {
    local: localSnippets.map(s => ({ id: s.id, title: s.title || null, tag: s.tag || null })),
    web: webResults
  };

  const logToDb = String(process.env.AI_LOG_TO_DB || "true").toLowerCase() === "true";
  if (logToDb) {
    try {
      await q(
        `INSERT INTO ai_log (user_id, question, reply, sources_json)
         VALUES (?, ?, ?, ?)`,
        [userId, question, reply, JSON.stringify(sources)]
      );
    } catch {
      // ha nincs tábla: ignore
    }
  }

  res.json({ reply, sources });
});

export default router;
