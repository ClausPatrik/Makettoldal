-- AI tudásbázis + log táblák (MySQL / MariaDB)
-- Futtasd le a saját makett adatbázisodban.

CREATE TABLE IF NOT EXISTS ai_knowledge (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NULL,
  tag VARCHAR(100) NULL,
  content MEDIUMTEXT NULL,
  answer MEDIUMTEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- FULLTEXT gyorsításhoz (InnoDB-n támogatott MariaDB/MySQL verziótól függ)
ALTER TABLE ai_knowledge
  ADD FULLTEXT KEY ft_ai_knowledge (title, tag, content, answer);

CREATE TABLE IF NOT EXISTS ai_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  question TEXT NOT NULL,
  reply MEDIUMTEXT NOT NULL,
  sources_json JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3 minta tudásbázis elem (bővítsd nyugodtan)
INSERT INTO ai_knowledge (title, tag, content, answer) VALUES
('Alap: felület előkészítés', 'alap', 'Zsírtalanítás, csiszolás, primer', 'Mosd le a darabokat langyos mosószeres vízzel, szárítsd meg, majd használj primert vékony rétegben.'),
('Festés: megfolyás', 'festes', 'Túl vastag réteg, túl híg festék', 'Csökkentsd a rétegvastagságot, fújj több vékony réteget, és hagyj száradási időt.'),
('Matrica: silvering', 'matrica', 'Levegő a matrica alatt', 'Fényes lakkréteg, matricalágyító (Micro Set/Sol), majd záró lakk segít.');
