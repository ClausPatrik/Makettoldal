# Makett AI – továbbfejlesztett, ingyenes (Node.js + MySQL + Web keresés)

Ez egy **működő** backend a meglévő AiChatWidget-hez.

## Mit tud?
- `POST /api/ai/ask` → választ ad heurisztikával
- Helyi tudásbázisból keres (MySQL `ai_knowledge`)
- Opcionálisan weben is keres (DuckDuckGo HTML) és forrásokat ad vissza
- Naplózza a kérdés-válasz párokat (`ai_log`)

> Nem LLM: viszont **ingyenes, működő, és iskolai projektre tökéletes.**  
> Később rá lehet kötni Ollama / OpenAI API-ra.

## Telepítés (suli gép)
1) DB táblák:
- phpMyAdmin → Importáld: `sql/ai_tables.sql`

2) Backend:
```bash
cd backend
copy .env.example .env
npm i
npm run dev
```

3) Frontend:
- A widgetből az API-t erre állítsd:
  - `VITE_API_URL=http://localhost:3001`

### Végpont
`POST http://localhost:3001/api/ai/ask`

Body:
```json
{ "question": "Hogyan kerüljem el a megfolyást airbrushnál?", "userId": 1 }
```

Válasz:
```json
{ "reply": "...", "sources": { "local": [...], "web": [...] } }
```

## Biztonság / megjegyzés
- A web keresés nem hivatalos API. Ha letiltják, csak a helyi tudásbázis megy tovább.
- `AI_ENABLE_WEB=false` → teljesen offline mód.
