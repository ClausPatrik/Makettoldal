import React, { useEffect, useMemo, useState } from "react";
import { useAuth } from "../context/AuthContext";

const API_BASE_URL = "http://localhost:3001/api";

/**
 * Fórum oldal:
 * - Bal oldalt témák listája
 * - Jobb oldalt: kiválasztott téma + hozzászólások
 * - Admin: mindent tud, user: csak a sajátját szerkesztheti/törölheti
 */
export default function Forum() {
  const { bejelentkezve, felhasznalo } = useAuth();

  // Admin ellenőrzés (nálad: szerepkor_id === 2)
  const isAdmin = felhasznalo?.szerepkor_id === 2;

  // Moderátor ellenőrzés (nálad: szerepkor_id === 3)
  const isModerator = felhasznalo?.szerepkor_id === 3;

  // Aktuális userId (ha nincs belépve, NaN lesz)
  const userId = Number(felhasznalo?.id);

  // ===== Témák (bal oldal) =====
  const [temak, setTemak] = useState([]);
  const [temaKereses, setTemaKereses] = useState("");
  const [kivalasztottTemaId, setKivalasztottTemaId] = useState(null);

  // ===== Üzenetek (jobb oldal) =====
  const [uzenetek, setUzenetek] = useState([]);
  const [ujUzenet, setUjUzenet] = useState("");

  // ===== Általános UI =====
  const [betoltes, setBetoltes] = useState(false);
  const [hiba, setHiba] = useState(null);

  // ===== Új téma (gombbal nyíló) =====
  const [ujTemaNyitva, setUjTemaNyitva] = useState(false);
  const [ujTemaCim, setUjTemaCim] = useState("");
  const [ujTemaKategoria, setUjTemaKategoria] = useState("általános");
  const [ujTemaLeiras, setUjTemaLeiras] = useState("");

  // ===== Téma szerkesztés (admin vagy szerző) =====
  const [temaEditNyitva, setTemaEditNyitva] = useState(false);
  const [temaEditForm, setTemaEditForm] = useState({
    cim: "",
    kategoria: "",
    leiras: "",
  });

  // ===== Üzenet szerkesztés (admin vagy szerző; egy darab egyszerre) =====
  const [uzenetEditId, setUzenetEditId] = useState(null);
  const [uzenetEditSzoveg, setUzenetEditSzoveg] = useState("");

  // ---------------------------------------------------------------------------
  // Segédek
  // ---------------------------------------------------------------------------
  function token() {
    return localStorage.getItem("token");
  }

  function formatDatum(datumStr) {
    if (!datumStr) return "";
    const d = new Date(datumStr);
    if (Number.isNaN(d.getTime())) return datumStr;
    return d.toLocaleString("hu-HU");
  }

  // Kiválasztott téma objektum
  const kivalasztottTema = useMemo(() => {
    return temak.find((t) => t.id === kivalasztottTemaId) || null;
  }, [temak, kivalasztottTemaId]);

  // Téma szerző ellenőrzése: admin VAGY szerző
  const temaSzerzoId = Number(kivalasztottTema?.felhasznalo_id);
  const canEditTema = isAdmin || (Number.isFinite(userId) && temaSzerzoId === userId);

  // Témák szűrése keresővel
  const szurtTemak = useMemo(() => {
    const q = temaKereses.trim().toLowerCase();
    if (!q) return temak;

    return temak.filter((t) => {
      const cim = (t.cim || "").toLowerCase();
      const leiras = (t.leiras || "").toLowerCase();
      const kat = (t.kategoria || "").toLowerCase();
      return cim.includes(q) || leiras.includes(q) || kat.includes(q);
    });
  }, [temak, temaKereses]);

  // ---------------------------------------------------------------------------
  // API: témák
  // ---------------------------------------------------------------------------
  async function betoltTemak() {
    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/temak`);
      if (!res.ok) throw new Error("Nem sikerült betölteni a témákat.");

      const adat = await res.json();
      setTemak(adat);

      // Ha még nincs kiválasztva, válasszuk az elsőt
      if (!kivalasztottTemaId && adat.length > 0) {
        setKivalasztottTemaId(adat[0].id);
      }
    } catch (err) {
      setHiba(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  async function letrehozTema(e) {
    e.preventDefault();
    if (!bejelentkezve) {
      alert("Új téma indításához jelentkezz be.");
      return;
    }

    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/temak`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token()}`,
        },
        body: JSON.stringify({
          cim: ujTemaCim,
          kategoria: ujTemaKategoria,
          leiras: ujTemaLeiras,
        }),
      });

      if (!res.ok) {
        const h = await res.json().catch(() => ({}));
        throw new Error(h.uzenet || "Nem sikerült létrehozni a témát.");
      }

      const uj = await res.json();

      // UI: téma lista elejére, és válasszuk ki
      setTemak((prev) => [uj, ...prev]);
      setKivalasztottTemaId(uj.id);

      // form reset + bezárás
      setUjTemaCim("");
      setUjTemaKategoria("általános");
      setUjTemaLeiras("");
      setUjTemaNyitva(false);
    } catch (err) {
      alert(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  // Téma mentés: admin vagy szerző (backendben is védekezik!)
  async function temaMentes() {
    if (!canEditTema || !kivalasztottTemaId) return;

    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/temak/${kivalasztottTemaId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token()}`,
        },
        body: JSON.stringify({
          cim: temaEditForm.cim,
          kategoria: temaEditForm.kategoria,
          leiras: temaEditForm.leiras,
        }),
      });

      if (!res.ok) {
        const h = await res.json().catch(() => ({}));
        throw new Error(h.uzenet || "Nem sikerült menteni a témát.");
      }

      const frissitett = await res.json();

      // Frissítjük a bal oldali listát
      setTemak((prev) => prev.map((t) => (t.id === frissitett.id ? frissitett : t)));

      setTemaEditNyitva(false);
    } catch (err) {
      alert(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  // Téma törlés: admin vagy szerző (backendben is védekezik!)
  async function temaTorles() {
    if (!canEditTema || !kivalasztottTemaId) return;

    if (!window.confirm("Biztosan törlöd ezt a témát? A hozzászólások is elveszhetnek.")) return;

    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/temak/${kivalasztottTemaId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token()}`,
        },
      });

      if (!res.ok) {
        const h = await res.json().catch(() => ({}));
        throw new Error(h.uzenet || "Nem sikerült törölni a témát.");
      }

      // UI: vegyük ki a listából + válasszunk másikat
      const ujLista = temak.filter((t) => t.id !== kivalasztottTemaId);
      setTemak(ujLista);
      setUzenetek([]);
      setTemaEditNyitva(false);

      setKivalasztottTemaId(ujLista.length > 0 ? ujLista[0].id : null);
    } catch (err) {
      alert(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  // ---------------------------------------------------------------------------
  // API: üzenetek
  // ---------------------------------------------------------------------------
  async function betoltUzenetek(temaId) {
    if (!temaId) return;
    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/temak/${temaId}/uzenetek`);
      if (!res.ok) throw new Error("Nem sikerült betölteni a hozzászólásokat.");

      const adat = await res.json();
      setUzenetek(adat);
    } catch (err) {
      setHiba(err.message);
      setUzenetek([]);
    } finally {
      setBetoltes(false);
    }
  }

  async function kuldUzenet(e) {
    e.preventDefault();
    if (!bejelentkezve) {
      alert("Hozzászóláshoz jelentkezz be.");
      return;
    }
    if (!kivalasztottTemaId) return;

    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/temak/${kivalasztottTemaId}/uzenetek`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token()}`,
        },
        body: JSON.stringify({ szoveg: ujUzenet }),
      });

      if (!res.ok) {
        const h = await res.json().catch(() => ({}));
        throw new Error(h.uzenet || "Nem sikerült elküldeni a hozzászólást.");
      }

      const uj = await res.json();
      setUzenetek((prev) => [...prev, uj]);
      setUjUzenet("");
    } catch (err) {
      alert(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  // Üzenet mentés (admin vagy szerző)
  async function uzenetMentes(uzenetId) {
    if (!uzenetId) return;

    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/uzenetek/${uzenetId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token()}`,
        },
        body: JSON.stringify({ szoveg: uzenetEditSzoveg }),
      });

      if (!res.ok) {
        const h = await res.json().catch(() => ({}));
        throw new Error(h.uzenet || "Nem sikerült menteni a hozzászólást.");
      }

      const frissitett = await res.json();

      setUzenetek((prev) => prev.map((u) => (u.id === frissitett.id ? frissitett : u)));
      setUzenetEditId(null);
      setUzenetEditSzoveg("");
    } catch (err) {
      alert(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  // Üzenet törlés (admin vagy szerző)
  async function uzenetTorles(uzenetId) {
    if (!uzenetId) return;
    if (!window.confirm("Biztosan törlöd ezt a hozzászólást?")) return;

    try {
      setBetoltes(true);
      setHiba(null);

      const res = await fetch(`${API_BASE_URL}/forum/uzenetek/${uzenetId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token()}`,
        },
      });

      if (!res.ok) {
        const h = await res.json().catch(() => ({}));
        throw new Error(h.uzenet || "Nem sikerült törölni a hozzászólást.");
      }

      setUzenetek((prev) => prev.filter((u) => u.id !== uzenetId));

      // ha épp ezt szerkesztette, zárjuk le
      if (uzenetEditId === uzenetId) {
        setUzenetEditId(null);
        setUzenetEditSzoveg("");
      }
    } catch (err) {
      alert(err.message);
    } finally {
      setBetoltes(false);
    }
  }

  // ---------------------------------------------------------------------------
  // Betöltések
  // ---------------------------------------------------------------------------
  useEffect(() => {
    betoltTemak();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // téma váltáskor:
  // - töltsük a hozzászólásokat
  // - szerkesztő formot állítsuk be a kiválasztott témára
  useEffect(() => {
    if (!kivalasztottTemaId) {
      setUzenetek([]);
      setTemaEditNyitva(false);
      return;
    }

    betoltUzenetek(kivalasztottTemaId);

    const tema = temak.find((t) => t.id === kivalasztottTemaId);
    if (tema) {
      setTemaEditForm({
        cim: tema.cim ?? "",
        kategoria: tema.kategoria ?? "",
        leiras: tema.leiras ?? "",
      });
    }

    // üzenetszerkesztés záródjon témaváltáskor
    setUzenetEditId(null);
    setUzenetEditSzoveg("");
    setTemaEditNyitva(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kivalasztottTemaId]);

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------
  return (
    <section className="page">
      <header className="page-header">
        <h1>Fórum</h1>
        <p className="small">
          Válassz témát bal oldalon, és a hozzászólások a jobb oldalon jelennek meg.
        </p>
      </header>

      {hiba && <p className="error">{hiba}</p>}
      {betoltes && <p className="small">Betöltés...</p>}

      {/* Új téma (gombbal nyíló) */}
      <div className="card">
        <div className="forum-newtopic-header">
          <h2 style={{ margin: 0 }}>Új téma</h2>
          <button
            type="button"
            className={ujTemaNyitva ? "btn secondary" : "btn"}
            onClick={() => setUjTemaNyitva((p) => !p)}
          >
            {ujTemaNyitva ? "Bezárás" : "Új téma indítása"}
          </button>
        </div>

        {ujTemaNyitva && (
          <div className="form" style={{ marginTop: 12 }}>
            {!bejelentkezve && <p className="small">Új téma indításához jelentkezz be.</p>}

            <form onSubmit={letrehozTema}>
              <label>
                Cím
                <input value={ujTemaCim} onChange={(e) => setUjTemaCim(e.target.value)} required />
              </label>

              <label>
                Kategória
                <select
                  value={ujTemaKategoria}
                  onChange={(e) => setUjTemaKategoria(e.target.value)}
                >
                  <option value="általános">Általános</option>
                  <option value="építési napló">Építési napló</option>
                  <option value="festés / weathering">Festés / weathering</option>
                  <option value="kezdők kérdeznek">Kezdők kérdeznek</option>
                  <option value="eszközök / anyagok">Eszközök / anyagok</option>
                </select>
              </label>

              <label>
                Leírás (nem kötelező)
                <textarea
                  value={ujTemaLeiras}
                  onChange={(e) => setUjTemaLeiras(e.target.value)}
                  rows={3}
                />
              </label>

              <div className="button-row">
                <button type="submit" className="btn" disabled={!bejelentkezve}>
                  Téma létrehozása
                </button>
                <button type="button" className="btn secondary" onClick={() => setUjTemaNyitva(false)}>
                  Mégse
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Két oszlopos elrendezés */}
      <div className="forum-layout" style={{ marginTop: 16 }}>
        {/* BAL: témák */}
        <div className="forum-right card">
          <h2>Témák</h2>

          {/* kereső mező formázott wrapperben */}
          <div className="filters" style={{ marginBottom: 10 }}>
            <input
              type="text"
              placeholder="Keresés cím / kategória / leírás..."
              value={temaKereses}
              onChange={(e) => setTemaKereses(e.target.value)}
            />
          </div>

          {szurtTemak.length === 0 ? (
            <p className="small">Nincs találat.</p>
          ) : (
            <ul className="forum-topic-list">
              {szurtTemak.map((t) => {
                const aktiv = t.id === kivalasztottTemaId;
                return (
                  <li
                    key={t.id}
                    className={aktiv ? "forum-topic active" : "forum-topic"}
                    onClick={() => setKivalasztottTemaId(t.id)}
                  >
                    <div>
                      <strong>{t.cim}</strong>
                      {t.kategoria && (
                        <span className="nav-badge" style={{ marginLeft: 8 }}>
                          {t.kategoria}
                        </span>
                      )}
                    </div>
                    <p className="small" style={{ margin: "4px 0 0 0" }}>
                      {t.felhasznalo_nev ? `Indította: ${t.felhasznalo_nev}` : ""}
                      {t.letrehozva ? ` • ${formatDatum(t.letrehozva)}` : ""}
                    </p>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* JOBB: hozzászólások */}
        <div className="forum-left card">
          {!kivalasztottTema ? (
            <p className="small">Válassz egy témát bal oldalon.</p>
          ) : (
            <>
              {/* Téma fejléc + szerkesztés gomb (admin vagy szerző) */}
              <div className="forum-topic-header">
                <div>
                  <h2 style={{ marginBottom: 4 }}>{kivalasztottTema.cim}</h2>
                  <p className="small" style={{ marginTop: 0 }}>
                    {kivalasztottTema.kategoria ? kivalasztottTema.kategoria : ""}
                    {kivalasztottTema.leiras ? ` • ${kivalasztottTema.leiras}` : ""}
                  </p>
                </div>

                {canEditTema && (
                  <button
                    type="button"
                    className="btn secondary"
                    onClick={() => setTemaEditNyitva((p) => !p)}
                    style={{ height: 40 }}
                  >
                    {temaEditNyitva ? "Szerkesztés bezárása" : "Téma szerkesztése"}
                  </button>
                )}
              </div>

              {/* Téma szerkesztés blokk */}
              {canEditTema && temaEditNyitva && (
                <div className="card form" style={{ marginTop: 12 }}>
                  <h3>Téma szerkesztése</h3>

                  <label>
                    Cím
                    <input
                      value={temaEditForm.cim}
                      onChange={(e) =>
                        setTemaEditForm((p) => ({ ...p, cim: e.target.value }))
                      }
                    />
                  </label>

                  <label>
                    Kategória
                    <input
                      value={temaEditForm.kategoria}
                      onChange={(e) =>
                        setTemaEditForm((p) => ({ ...p, kategoria: e.target.value }))
                      }
                    />
                  </label>

                  <label>
                    Leírás
                    <textarea
                      value={temaEditForm.leiras}
                      onChange={(e) =>
                        setTemaEditForm((p) => ({ ...p, leiras: e.target.value }))
                      }
                      rows={3}
                    />
                  </label>

                  <div className="button-row">
                    <button type="button" className="btn" onClick={temaMentes}>
                      Mentés
                    </button>
                    <button
                      type="button"
                      className="btn secondary"
                      onClick={() => setTemaEditNyitva(false)}
                    >
                      Mégse
                    </button>

                    <button type="button" className="btn danger" onClick={temaTorles}>
                      Téma törlése
                    </button>
                  </div>
                </div>
              )}

              {/* Üzenetek listája */}
              {uzenetek.length === 0 ? (
                <p className="small" style={{ marginTop: 12 }}>
                  Még nincs hozzászólás ebben a témában.
                </p>
              ) : (
                <ul className="forum-msg-list" style={{ marginTop: 12 }}>
                  {uzenetek.map((u) => {
                    const szerkeszt = uzenetEditId === u.id;

                    // jogosultság: admin vagy szerző (ez csak itt létezik!)
                    const uzenetSzerzoId = Number(u.felhasznalo_id);
                    const canEditUzenet =
                      isAdmin || (Number.isFinite(userId) && uzenetSzerzoId === userId);

                    const canDeleteUzenet =
                      isAdmin || isModerator || (Number.isFinite(userId) && uzenetSzerzoId === userId);

                    return (
                      <li key={u.id} className="forum-msg">
                        <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                          <div>
                            <strong>{u.felhasznalo_nev || "Felhasználó"}</strong>
                            <p className="small" style={{ margin: 0 }}>
                              {formatDatum(u.letrehozva)}
                            </p>
                          </div>

                        {!szerkeszt && (
                        <div style={{ display: "flex", gap: 8 }}>
                          {canEditUzenet && (
                            <button
                            type="button"
                            className="btn secondary forum-admin-btn"
                          onClick={() => {
                            setUzenetEditId(u.id);
                            setUzenetEditSzoveg(u.szoveg || "");
                          }}
                          >
                          Szerkesztés
                          </button>
                         )}

                          {canDeleteUzenet && (
                            <button
                          type="button"
                           className="btn danger"
                          onClick={() => uzenetTorles(u.id)}
                         >
                         Törlés
                        </button>
                         )}
                        </div>
                        )}
                        </div>

                        {/* Üzenet tartalom / szerkesztő mód */}
                        {!szerkeszt ? (
                          <p style={{ marginTop: 8 }}>{u.szoveg}</p>
                        ) : (
                          <div className="form" style={{ marginTop: 8 }}>
                            <label>
                              Hozzászólás szerkesztése
                              <textarea
                                value={uzenetEditSzoveg}
                                onChange={(e) => setUzenetEditSzoveg(e.target.value)}
                                rows={3}
                              />
                            </label>

                            <div className="button-row">
                              <button
                                type="button"
                                className="btn"
                                onClick={() => uzenetMentes(u.id)}
                              >
                                Mentés
                              </button>

                              <button
                                type="button"
                                className="btn secondary"
                                onClick={() => {
                                  setUzenetEditId(null);
                                  setUzenetEditSzoveg("");
                                }}
                              >
                                Mégse
                              </button>

                              {/* törlés csak szerkesztés közben */}
                              {canDeleteUzenet && (
                                <button
                                  type="button"
                                  className="btn danger"
                                  onClick={() => uzenetTorles(u.id)}
                                >
                                  Törlés
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}

              {/* Új hozzászólás */}
              <div style={{ marginTop: 12 }}>
                {bejelentkezve ? (
                  <form onSubmit={kuldUzenet} className="form">
                    <label>
                      Új hozzászólás
                      <textarea
                        value={ujUzenet}
                        onChange={(e) => setUjUzenet(e.target.value)}
                        rows={3}
                        required
                      />
                    </label>

                    <div className="button-row">
                      <button type="submit" className="btn">
                        Küldés
                      </button>
                    </div>
                  </form>
                ) : (
                  <p className="small">Hozzászóláshoz jelentkezz be.</p>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
